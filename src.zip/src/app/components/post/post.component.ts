import { Component, Input } from '@angular/core';
import { Post } from 'src/app/classes/post';


@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.scss']
})
export class PostComponent {
  @Input() post: Post|any = {};

  like() {
    this.post.likes += 1;
  }
  comment() {
    this.post.comments += 1;
  }
  tweet() {
    this.post.retweets += 1;
  }
}
