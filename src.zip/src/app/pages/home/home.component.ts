import { Component } from '@angular/core';
import { Post } from 'src/app/classes/post';
import { ApiService } from 'src/app/services/api.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  constructor(private api: ApiService) {}
  
  posts: Post[] = [];

  ngOnInit() {
    this.getData();
  }

  getData() {
    this.posts = this.api.get_posts();
  }
}
