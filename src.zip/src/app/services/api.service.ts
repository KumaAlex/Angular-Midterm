import { Injectable } from '@angular/core';
import axios, { Axios } from 'axios';
import { Observable, BehaviorSubject } from 'rxjs';
import { Post } from '../classes/post';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  private BaseUrl = './Twitter/src/fake_data.json';

  data = [
    {
      id: 1,
      author: 'John Doe',
      username: '@johndoe',
      avatar: 'https://example.com/avatar1.jpg',
      tweetText: 'Just had a fantastic dinner at my favorite restaurant!',
      image:
        'https://bogatyr.club/uploads/posts/2023-02/1677593199_bogatyr-club-p-chelovek-v-beloi-futbolke-foni-oboi-82.jpg',
      likes: 102,
      comments: 23,
      retweets: 15,
      post_img:
        'https://optimetr.net/wp-content/uploads/2019/07/kontekstnaya_reklama.jpg',
    },
    {
      id: 2,
      author: 'Alice Smith',
      username: '@alicesmith',
      avatar: 'https://example.com/avatar2.jpg',
      tweetText: 'Exploring new places and making memories. #TravelLife',
      image:
        'http://sipelandscapinganddesign.com/wp-content/uploads/2016/05/slider_1_wmn_img.png',
      likes: 321,
      comments: 45,
      retweets: 78,
      post_img:
        'https://optimetr.net/wp-content/uploads/2019/07/kontekstnaya_reklama.jpg',
    },
    {
      id: 3,
      author: 'Ella Johnson',
      username: '@ellajohnson',
      avatar: 'https://example.com/avatar3.jpg',
      tweetText: "Just finished reading an amazing book. Couldn't put it down!",
      image:
        'http://sipelandscapinganddesign.com/wp-content/uploads/2016/05/slider_1_wmn_img.png',
      likes: 452,
      comments: 67,
      retweets: 134,
      post_img:
        'https://optimetr.net/wp-content/uploads/2019/07/kontekstnaya_reklama.jpg',
    },
    {
      id: 4,
      author: 'Michael Brown',
      username: '@michaelbrown',
      avatar: 'https://example.com/avatar4.jpg',
      tweetText: 'Enjoying the beautiful sunset at the beach. #NatureLover',
      image:
        'https://bogatyr.club/uploads/posts/2023-02/1677593199_bogatyr-club-p-chelovek-v-beloi-futbolke-foni-oboi-82.jpg',
      likes: 789,
      comments: 98,
      retweets: 256,
      post_img:
        'https://optimetr.net/wp-content/uploads/2019/07/kontekstnaya_reklama.jpg',
    },
    {
      id: 5,
      author: 'Olivia Davis',
      username: '@oliviadavis',
      avatar: 'https://example.com/avatar5.jpg',
      tweetText: 'Celebrating my birthday with friends and family! 🎂🎉',
      image:
        'http://sipelandscapinganddesign.com/wp-content/uploads/2016/05/slider_1_wmn_img.png',
      likes: 1234,
      comments: 210,
      retweets: 567,
      post_img:
        'https://optimetr.net/wp-content/uploads/2019/07/kontekstnaya_reklama.jpg',
    },
    {
      id: 6,
      author: 'Liam Wilson',
      username: '@liamwilson',
      avatar: 'https://example.com/avatar6.jpg',
      tweetText:
        'Coding all night and building awesome projects! 💻 #DeveloperLife',
      image:
        'https://bogatyr.club/uploads/posts/2023-02/1677593199_bogatyr-club-p-chelovek-v-beloi-futbolke-foni-oboi-82.jpg',
      likes: 567,
      comments: 76,
      retweets: 189,
      post_img:
        'https://optimetr.net/wp-content/uploads/2019/07/kontekstnaya_reklama.jpg',
    },
    {
      id: 7,
      author: 'Ava Lee',
      username: '@avalee',
      avatar: 'https://example.com/avatar7.jpg',
      tweetText:
        'Just adopted a cute puppy! Meet my new furry friend, Max. 🐾❤️',
      image:
        'http://sipelandscapinganddesign.com/wp-content/uploads/2016/05/slider_1_wmn_img.png',
      likes: 987,
      comments: 132,
      retweets: 345,
      post_img:
        'https://optimetr.net/wp-content/uploads/2019/07/kontekstnaya_reklama.jpg',
    },
  ];

  private currentData = new BehaviorSubject<Post[]>([]);
  sharedData = this.currentData.asObservable();
  constructor() {}

  get_posts() {
    return this.data;
  }
}
