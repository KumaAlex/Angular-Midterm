export class Post {
  'id': number;
  'author': string;
  'username': string;
  'avatar': string;
  'tweetText': string;
  'image': string;
  'likes': number;
  'comments': number;
  'retweets': number;
  'post_img': string;
}
